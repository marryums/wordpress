(function($){
	$( function(){
	console.log( 'Hello Test' );

	 $( "#ultdatetime" ).datepicker();
	
	});
	
	
})(jQuery);